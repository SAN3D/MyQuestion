package com.questionpaper.repository

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class QuestionPaperApplication : Application()