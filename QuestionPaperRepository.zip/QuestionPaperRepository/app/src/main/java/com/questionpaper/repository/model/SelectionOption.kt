package com.questionpaper.repository.model

data class SelectionOption(
    val id: Int,
    val displayName: String
)